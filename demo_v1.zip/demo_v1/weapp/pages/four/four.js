// pages/four/four.js
var app=getApp()
Page({
  data:{
    Goodsurl:[],
    GoodInfo:{},
    id1:false,
    id2:false

  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady:function(){
    // 页面渲染完成
    this.setData({
      Goodsurl: app.data.GoodsUrl,
      GoodInfo: app.data.GoodsInfo
    })
    console.log(this.data.GoodInfo)
  },
  onclock1: function (e) {
    console.log(e)
    this.setData({
      id1: !this.data.id1
    })
    console.log(e.target.id)
    console.log(this.data.id2)
  },
  onclock2: function (e) {
    console.log(e)
    this.setData({
      id2: !this.data.id2
    })
    console.log(e.target.id)
    console.log(this.data.id2)
  },
  onShow:function(){
    // 页面显示
    /*this.setData({
        Goodsurl:app.data.GoodsUrl
        
    })*/
    //console.log(this.data.Goodsurl)
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})