// pages/five/five.js
var deleteurl ='https://32906079.jxggdxw.com:8443/WeappServer/DownloadInfo'
var app=getApp();
var value=[]
var Goodsinfo=[]
var Name=[]
var namess={name:''}
Page({
  data:{
    goodsname:[],
    names:{ name: '' },
    goodsinfo:[],
    selected:[]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    this.setData({
       goodsname:app.data.GoodsName,
       goodsinfo: app.data.goodsinfo
    })
    console.log(this.data.goodsname)
  },
  checkboxChange: function(e) {
     value=e.detail.value
  },
  selected:function(e){
    console.log(e.target.id)
    Goodsinfo=this.data.goodsinfo;
    console.log(Goodsinfo[e.target.id].selected)
    Goodsinfo[e.target.id].selected = !Goodsinfo[e.target.id].selected
    console.log(Goodsinfo[e.target.id].selected)
    this.setData({
         goodsinfo: Goodsinfo
    })
  },
  complete: function () {
    Name.splice(0,Name.length)
    for(var i=0;i<this.data.goodsinfo.length;i++){
      if (this.data.goodsinfo[i].selected){
        Name.push(this.data.goodsinfo[i].goodsname)
      } 
    }
    console.log(Name)
    /*wx.request({
        url: deleteurl ,
        data: {
          command: 'delgoodinfo',
          names: Name    //name是一个数组，数组里的内容为要删除商品的名字
      },
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      }, // 设置请求的 header
      success: function (res) { 
       // console.log(Name)
       }
     })*/
    wx.showLoading({
      title: '加载中',
    })
    setTimeout(function () {
      wx.hideLoading()
    }, 1000)
   // wx.redirectTo({       //跳转到tb页面
   //   url: '../first/first',
   // })
  },
  
  onReady:function(){
    // 页面渲染完成
  },
  onShow:function(){
    // 页面显示
  },
  onHide:function(){
    // 页面隐藏
  },
  onUnload:function(){
    // 页面关闭
  }
})